# Details

Rename this file in the format `yourRollNumber_solution.md` (example, `210000_solution.md`)

## Your zeroth approach below

Reasoning - %%% Type your approach here %%%

```md
%%% Replace this with the 0th challenge answer %%%
```

---

## Your first approach below

Reasoning - %%% Type your approach here %%%

```
%%% Replace this with the 1st challenge answer %%%
```

---

## Your second approach below

Reasoning - %%% Type your approach here %%%

```
%%% Replace this with the 2nd challenge answer %%%
```

---

## Your third approach below

Reasoning - %%% Type your approach here %%%

```
%%% Replace this with the 3rd challenge answer %%%
```

- Name :
- Roll :

## Do not tamper below this line

---

Q29yZSB0ZWFtIGtvIGZha2UgZG8=
